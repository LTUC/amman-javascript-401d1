import React from "react";
import Modal from "./modal.js";

export default props => <Modal {...props} />;
