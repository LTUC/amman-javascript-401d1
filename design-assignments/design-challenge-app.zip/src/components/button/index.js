import React from "react";
import Button from "./button.js";

export default props => <Button {...props} />;
