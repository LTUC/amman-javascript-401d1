import React from "react";
import Drawer from "./drawer.js";

export default props => <Drawer {...props} />;
