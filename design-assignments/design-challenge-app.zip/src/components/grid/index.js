import React from "react";
import Grid from "./grid.js";

export default props => <Grid {...props} />;
