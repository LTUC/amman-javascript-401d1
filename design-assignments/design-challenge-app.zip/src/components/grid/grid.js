import React from 'react';

import './grid.scss';

const Grid = props => {
  return (
    <section>
      <div>Grid Content</div>
    </section>
  );
};

export default Grid;
