import React from "react";
import Card from "./card.js";

export default props => <Card {...props} />;
