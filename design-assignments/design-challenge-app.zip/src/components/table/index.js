import React from "react";
import Table from "./table.js";

export default props => <Table {...props} />;
