import React from "react";
import Link from "./link.js";

export default props => <Link {...props} />;
