import React from "react";
import Deck from "./deck.js";

export default props => <Deck {...props} />;
