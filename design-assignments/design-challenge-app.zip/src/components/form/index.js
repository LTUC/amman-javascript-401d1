import React from 'react';
import Form from './form.js';

export default props => <Form {...props} />;
