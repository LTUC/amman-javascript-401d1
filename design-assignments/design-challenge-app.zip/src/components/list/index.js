import React from 'react';
import List from './list.js';

export default props => <List {...props} />;
