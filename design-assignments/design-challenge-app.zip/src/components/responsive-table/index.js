import React from "react";
import ResponsiveTable from "./responsive-table.js";

export default props => <ResponsiveTable {...props} />;
